#include "PaliaInternal.hpp"

using namespace UC;

VOID PaliaInternal::GetValeriaCharacter(VOID) {
    if (NULL != lpValeriaCharacter) {
        return;
    }

    for (int32 i = 0; i < SDK::UObject::GObjects->Num(); i++) {
        SDK::UObject *lpObj = SDK::UObject::GObjects->GetByIndex(i);
        if (NULL == lpObj) {
            continue;
        }

        if (lpObj->IsA(SDK::AValeriaCharacter::StaticClass()) && !lpObj->IsDefaultObject()) {
            lpValeriaCharacter = (SDK::AValeriaCharacter *) lpObj;
            break;
        }
    }
}

BOOL PaliaInternal::HookProcessEvent(VOID) {
    if (NULL == lpValeriaCharacter) {
        fprintf(
            stderr,
            "[-] ValeriaCharacter is not initialized\n"
        );
        return FALSE;
    }

    DWORD dwOldProtect = 0;

    lpTargetInstance = lpValeriaCharacter->Placement;
    lpVTable = *(LPVOID **) lpTargetInstance;

    if (!VirtualProtect(
        lpVTable,
        0x1000,
        PAGE_EXECUTE_READWRITE,
        &dwOldProtect
    )) {
        fprintf(
            stderr,
            "[-] VirtualProtect() - E%lu\n",
            GetLastError()
        );
        return FALSE;
    }

    OriginalProcessEvent = (ProcessEvent_t) ((UINT_PTR) GetModuleHandle(NULL) + SDK::Offsets::ProcessEvent);
    lpVTable[SDK::Offsets::ProcessEventIdx] = HookedProcessEvent;

    VirtualProtect(
        lpVTable,
        0x1000,
        dwOldProtect,
        &dwOldProtect
    );

    return TRUE;
}

BOOL PaliaInternal::InitInternal(VOID) {
    GetValeriaCharacter();
    if (NULL == lpValeriaCharacter) {
        fprintf(
            stderr,
            "[-] Failed to get ValeriaCharacter\n"
        );
        return FALSE;
    }

    if (!HookProcessEvent()) {
        fprintf(
            stderr,
            "[-] Failed to hook ProcessEvent\n"
        );
        return FALSE;
    }

    return TRUE;
}

#ifdef _MANUAL_ADJUSTMENT
VOID PaliaInternal::EvaluateCoordinateAdjustment(
    CoordinateAdjustement_t AdjustmentType,
    UpdateLockedItemToPlace_t *lpUpdatePlaceParams
) {
    switch (AdjustmentType) {
        case PositionXPlus:
            ModifiedPosition.X += 1.0f;
            break;

        case PositionXMinus:
            ModifiedPosition.X -= 1.0f;
            break;

        case PositionYPlus:
            ModifiedPosition.Y += 1.0f;
            break;

        case PositionYMinus:
            ModifiedPosition.Y -= 1.0f;
            break;

        case PositionZPlus:
            ModifiedPosition.Z += 1.0f;
            break;

        case PositionZMinus:
            ModifiedPosition.Z -= 1.0f;
            break;

        case RotationPitchPlus:
            ModifiedRotation.Pitch += 1.0f;
            break;

        case RotationPitchMinus:
            ModifiedRotation.Pitch -= 1.0f;
            break;

        case RotationYawPlus:
            ModifiedRotation.Yaw += 1.0f;
            break;

        case RotationYawMinus:
            ModifiedRotation.Yaw -= 1.0f;
            break;

        case RotationRollPlus:
            ModifiedRotation.Roll += 1.0f;
            break;

        case RotationRollMinus:
            ModifiedRotation.Roll -= 1.0f;
            break;

        default:
            break;
    }
}

VOID PaliaInternal::EvaluateKeyPress(
    UpdateLockedItemToPlace_t *lpUpdatePlaceParams
) {
    if (GetAsyncKeyState(VK_UP)) {
        EvaluateCoordinateAdjustment(PositionZPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_DOWN)) {
        EvaluateCoordinateAdjustment(PositionZMinus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD8)) {
        EvaluateCoordinateAdjustment(PositionYMinus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD2)) {
        EvaluateCoordinateAdjustment(PositionYPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD4)) {
        EvaluateCoordinateAdjustment(PositionXMinus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD6)) {
        EvaluateCoordinateAdjustment(PositionXPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD7)) {
        EvaluateCoordinateAdjustment(RotationYawPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD9)) {
        EvaluateCoordinateAdjustment(RotationYawMinus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD3)) {
        EvaluateCoordinateAdjustment(RotationPitchMinus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD1)) {
        EvaluateCoordinateAdjustment(RotationPitchPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD5)) {
        EvaluateCoordinateAdjustment(RotationRollPlus, lpUpdatePlaceParams);
    } else if (GetAsyncKeyState(VK_NUMPAD0)) {
        EvaluateCoordinateAdjustment(RotationRollMinus, lpUpdatePlaceParams);
    } else {
        return;
    }
    bModifiedCoords = true;
}

BOOL PaliaInternal::GetPlaceItemFunction(
    SDK::UPlacementComponent *lpPlacementComponent
) {
    if (NULL != lpPlaceItemFunc) {
        return TRUE;
    }

    lpPlaceItemFunc = 
        (SDK::UFunction *) lpPlacementComponent->FindObject(strPaliaFunc_PlaceItem);

    return (NULL != lpPlaceItemFunc);
}
#endif

VOID PaliaInternal::HookedProcessEvent(
        const SDK::UObject *lpClass,
        class SDK::UFunction *lpFunction,
        LPVOID lpParams
) {
    SDK::UFunction *lpTargetFunction = lpFunction;  // For overrides
    LPVOID lpTargetParams = lpParams;
    
    const std::string strFunctionName = lpFunction->GetFullName();
    const std::string strClassName = lpClass->GetFullName();

    if (strClassName.starts_with("PlacementComponent")) {
        SDK::UPlacementComponent *lpPlacementComponent = (SDK::UPlacementComponent *) lpClass;
        lpPlacementComponent->CanPlaceHere = true;
#ifdef _MANUAL_ADJUSTMENT
        if (strFunctionName != strPaliaFunc_UpdateLockedItem) {
            UpdateLockedItemToPlace_t *lpUpdateLockedItemToPlace = (UpdateLockedItemToPlace_t *) lpParams;
            
            if (!bModifiedCoords) {
                memcpy(
                    &ModifiedPosition,
                    &lpUpdateLockedItemToPlace->Position,
                    sizeof(SDK::FVector)
                );

                memcpy(
                    &ModifiedRotation,
                    &lpUpdateLockedItemToPlace->Rotation,
                    sizeof(SDK::FRotator)
                );
            }

            EvaluateKeyPress((UpdateLockedItemToPlace_t *) lpParams);

            if (GetAsyncKeyState(VK_F9)) {
                
                memcpy(
                    &SavedPosition,
                    &lpUpdateLockedItemToPlace->Position,
                    sizeof(SDK::FVector)
                );

                memcpy(
                    &SavedRotation,
                    &lpUpdateLockedItemToPlace->Rotation,
                    sizeof(SDK::FRotator)
                );

                memcpy(
                    &BackupPosition,
                    &lpUpdateLockedItemToPlace->Position,
                    sizeof(SDK::FVector)
                );

                memcpy(
                    &BackupRotation,
                    &lpUpdateLockedItemToPlace->Rotation,
                    sizeof(SDK::FRotator)
                );
                
            } else if (GetAsyncKeyState(VK_F10)) {
                // Place Saved Position
                if (bGotRequiredParams) {
                    if (!GetPlaceItemFunction(lpPlacementComponent)) {
                        goto _UNHOOKED_EVENT;
                    }

                    PlacementParams.Position = SavedPosition;
                    PlacementParams.Rotation = SavedRotation;

                    lpTargetFunction = lpPlaceItemFunc;
                    lpTargetParams = &PlacementParams;
                }
            } else if (GetAsyncKeyState(VK_F6)) {
                // Restore Backup Position
                memcpy(
                    &SavedPosition,
                    &BackupPosition,
                    sizeof(SDK::FVector)
                );

                memcpy(
                    &SavedRotation,
                    &BackupRotation,
                    sizeof(SDK::FRotator)
                );
            }
        }

        if (strFunctionName == strPaliaFunc_PlaceItem && bModifiedCoords) {
            PlaceItem_t *lpPlaceItemParams = (PlaceItem_t *) lpParams;

            lpPlaceItemParams->Position = ModifiedPosition;
            lpPlaceItemParams->Rotation = ModifiedRotation;

            bModifiedCoords = false;
        }

#endif
    }
_UNHOOKED_EVENT:
    OriginalProcessEvent(lpClass, lpTargetFunction, lpTargetParams);
}